export interface Workout {
    type: string;
    duration: number;
    userName: string;
  }
  